def count_items(items):
    """Return the number of items. An empty list has zero items."""
    return len(items)
