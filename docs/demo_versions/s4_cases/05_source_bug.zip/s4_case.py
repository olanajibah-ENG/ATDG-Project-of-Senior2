def count_items(items):
    """Return the number of items. An empty list has zero items.

    >>> count_items([])
    0
    """
    if items:
        return len(items)
    return None
