import six


def is_text(value):
    """Return True for a string and False for a number."""
    return isinstance(value, six.string_types)
