import s4_demo_absent_module


def count_items(items):
    """Return the number of items, including zero for an empty list."""
    return s4_demo_absent_module.count_items(items)
