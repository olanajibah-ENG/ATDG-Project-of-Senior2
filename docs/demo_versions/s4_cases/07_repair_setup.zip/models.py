from dataclasses import dataclass


@dataclass
class Product:
    price: int
    stock: int = 0

    def reserve(self, quantity):
        if quantity <= 0 or quantity > self.stock:
            raise ValueError("quantity exceeds available stock")
        self.stock -= quantity


class Order:
    def __init__(self):
        self.lines = []

    def add_item(self, product, quantity):
        product.reserve(quantity)
        self.lines.append(product.price * quantity)

    def total(self):
        """Return the sum of the line totals in whole currency units."""
        return sum(self.lines)
